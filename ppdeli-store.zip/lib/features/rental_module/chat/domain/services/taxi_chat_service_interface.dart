abstract class TaxiChatServiceInterface {

}