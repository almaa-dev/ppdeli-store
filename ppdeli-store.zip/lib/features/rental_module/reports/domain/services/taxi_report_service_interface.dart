abstract class TaxiReportServiceInterface {

}