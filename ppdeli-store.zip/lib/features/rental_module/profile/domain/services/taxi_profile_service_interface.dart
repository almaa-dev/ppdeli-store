abstract class TaxiProfileServiceInterface {

}